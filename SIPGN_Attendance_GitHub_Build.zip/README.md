# SIPGN Attendance Android (WebView)

Aplikasi Android sederhana yang membuka halaman resmi:
https://sipgn-siphr.bgn.go.id/manajemen-tenaga-kerja/attendance/online

## Membuat APK
1. Ekstrak ZIP ini.
2. Buka Android Studio, pilih **Open**, lalu pilih folder `SIPGN_Attendance_Android`.
3. Tunggu Gradle Sync selesai. Gunakan JDK 17 dan Android SDK Platform 35.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur
- WebView dengan JavaScript dan penyimpanan sesi web.
- Tombol kembali Android menavigasi halaman sebelumnya.
- Dukungan permintaan kamera, lokasi, dan pemilih file dari situs (sesuai izin yang disetujui pengguna).
- Tautan web di luar domain BGN dibuka di browser eksternal.
- Tidak menonaktifkan validasi sertifikat HTTPS.

## Catatan
- Aplikasi ini adalah pembungkus web, bukan aplikasi resmi yang diterbitkan BGN.
- Login, absensi, serta data tetap ditangani oleh situs tujuan.
- Jika situs membutuhkan verifikasi perangkat atau memblokir WebView, gunakan browser Chrome.
- Nama paket saat ini `id.go.bgn.sipgnattendance`; ubah hanya jika Anda memiliki alasan dan konfigurasi penandatanganan yang sesuai.


## Build APK melalui GitHub Actions (tanpa Android Studio di komputer)
1. Buat repository GitHub baru dan unggah seluruh isi folder proyek ini.
2. Buka tab **Actions** pada repository.
3. Pilih workflow **Build Android APK**, lalu klik **Run workflow** (atau lakukan push ke branch `main`/`master`).
4. Setelah selesai, buka hasil run dan unduh artifact `SIPGN-Attendance-APK`.
5. Ekstrak artifact untuk memperoleh `app-debug.apk`, lalu kirim ke HP dan instal. Android mungkin meminta izin **Install unknown apps** untuk aplikasi/file manager yang digunakan.

APK yang dibangun adalah APK debug untuk uji/penggunaan pribadi, bukan rilis resmi BGN.


## Build APK otomatis lewat GitHub Actions
1. Upload seluruh isi folder proyek ini, termasuk `.github/workflows/build.yml`, ke repository GitHub.
2. Pastikan branch bernama `main`.
3. Buka tab **Actions** dan aktifkan GitHub Actions jika diminta.
4. Pilih workflow **Build SIPGN Attendance APK**, tekan **Run workflow**.
5. Setelah status berhasil (hijau), buka hasil run.
6. Unduh artifact **SIPGN-Attendance-APK**. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.
